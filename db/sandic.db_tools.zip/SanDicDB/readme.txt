1. Получить необходимые файлы
   Apte -> fetcher.pl
   Mac  -> fetcher.pl
   MW   -> загрузить вручную monier.xml
2. Создать БД sandic.db выполнив sandic.db.sql
3. _add.bat добавить данные в БД
   _del.bat удалить временные файлы
4. Записать статистику
   _finalize.bat