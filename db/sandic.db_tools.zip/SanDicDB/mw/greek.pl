use strict;

open(IN, "<:utf8",  "greek.txt") or die;

my (%records, $l, $key);

while (<IN>) {
    chomp;
    next if (/\s*#/);
    next if (/^$/);
   
    if (/^(\d+.*)\t+(.+)\t+(.+)\t+(.+)/) {
        my $g = $4;
        ($l, $key) = ($1, $2);
          
        $l   =~ s/(\.\d)0$/$1/; # 98138.60 -> 98138.6
        $key =~ s/\s//g;

        push (@{$records{$l}{$key}}, $g);
    } else {
        /(.+)\t(.*)/;
        push (@{$records{$l}{$key}}, ($2 || '?'));
    }
}

open(OUT, ">:utf8",  "greek.ready.txt") or die;

foreach my $l (sort keys %records) {
    my $text = "$l;";

    foreach (keys %{$records{$l}}) {
        $text .= "$_;";
        $text .= join(';', @{$records{$l}{$_}});
            
        print OUT "$text\n";
    }
}