use utf8;

use strict;

my $V = "aAiIuUfFxXeEoO";	                    # vowels
my $C = "kKgGNcCjJYwWqQRtTdDnpPbBmyrlL|vSzsh"; # consonants
my $X = "MHVZ";		                          # special class for anusvara & visarga, jihvamuliya, upadhmaniya
my $W = "'.0-9";                               # avagraha, danda (double danda не кодируется), numbers

open(IN,  "<:utf8", "greek.ready.txt") or die;

my %greek;

while (<IN>) {
    chomp;
    
     my ($l, $word, @greek) = split(';', $_);
     $greek{$l} = \@greek;
}

open(IN,  "<:utf8", "monier.xml") or die;
open(OUT, ">:utf8", "monier.txt") or die;

my ($root, $text, $origin, $word);

while (<IN>) {
    chomp;

    # начало записи
    $root  = $1 if /^<(H[1-4][ABC]?|HPW)>/;
    $text .= $_ if $root;
    
    # конец записи 
    if (/<\/($root)>\s*$/) {
       
        if (/<key1>(.*)<\/key1>/) {
            ($origin, $word) = ($text, $1);
          
            my $text = replace($origin);
            $word = slp1_utf8($word);
              
            print OUT "<key1>$word<\/key1>$text\n";
        }

        $text = undef;
    }
}

sub replace($text) {
    my $_ = shift; 
 
    # ********************************************
    # замена тагов и элементов
    # ********************************************
    s/<see\/>/see/g;  

    # <p> <p1> <b> <b1>
    # These elements mark material appearing within parentheses '()' in the text, in the same way that <b> and <b1> mark bracketed material
    s/<p1?>/\(/g;    # ()
    s/<\/p1?>/\)/g;
    s/<b1?>/\[/g;    # []
    s/<\/b1?>/\]/g;   
   
    s/<qv\/>/<ab>q.v.<\/ab>/g; # quod vide на q.v.
    s/<cf\/>/<ab>cf.<\/ab>/g;  # confer на cf.
    s/([^a-zA-Z0-9])N[.]/$1<ab>N.<\/ab>/g;

    # <etc/> <etc1/> <etcetc/>  
    # Represent various kinds of '&c.' &amp;c  
    #s/<etc1\/>|<etcetc\/>/<etc\/>/g;
    s/<(etc1|etcetc|etc)\/>/&c\./g;
   
    # <amp/> 
    # Represents the '&' character
    s/<amp\/>/&/g;
   
    # <msc/> 
    # Represents ';' when deemed to have a 'sense-separator' function. Occurs almost exclusively within records for verbs
    s/<msc\/>/;/g;
   
    # <eq/>  
    # Represents '=' character which appears in definitions in the form 'word1 = word2'
    s/<eq\/>/=/g;
   
    s/(<quote>)\s*/$1"/g;
    s/\s*(<\/quote>)/"$1/g;
   
    # <fs/>
    # Represents '/' character which appears in the text as a separator between alternatives. 
    s/<fs\/>/\//g;
   
    # <shortlong/> <shc/> 
    # represents, within Sanskrit text, the superscript symbol (line below semi-circle) used above a vowel to indicate that the vowel may be either in short or long form
    # There is probably no need for two elements, and the <shc/> could be changed to <shortlong/>
    # s/<shc\/>/<shortlong\/>/g;
    s/<(shc|shortlong)\/>//g;
   
    s/lex(\s*type=.+?)>/lex>/g;
   
    # <auml/> <ouml/> <uuml/> <euml/>
    # Represent the various umlaut characters
    s/<auml\/>/\x{00e4}/g;
    s/<ouml\/>/\x{00f6}/g;
    s/<uuml\/>/\x{00fc}/g;
    s/<euml\/>/\x{00eb}/g;
 
    # <gk>
    # Greek text
    /<L>(.*?)<\/L>/; # !!! tail section
    my $l = $1;
   
    s/<gk>(.*?)<\/gk>/"<etym>" . &greek($l, $1) . "<\/etym>"/ge;
 
    # <root>                head section
    # This is used to specify the verbal root in prefixed verbs, for instance 'ati-<root>kfz</root>'
    # This element also appears for the same purpose for those prefixed verbs for which the spelling is altered in the key due to sandhi
    # <root> and <root/>    body section
    # Mark Sanskrit roots. The empty element precedes the root, as in '<root/>~<s>pUR</s>'
    s/<root>(.*?)<\/root>/\x{221a}$1/; # head, квадратный корень
    s/<root\/?>/\x{221a}/g;            # body

    # <sr/> <sr1/> 
    # represents, within Sanskrit text, the small superscript circle used within the dictionary to represent omitted characters
    # This one of the numerous abbreviation techniques used in the dictionary
    #s/<sr1?\/>/\x{00b0}/g; # градус
    s/<sr1?\/>/\x{02da}/g; 
   
    # <srs/> <srs1/> 
    # represents, within Sanskrit text, the circumflex used within the dictionary to represent single replacement sandhi
    s/<srs1?\/>/\*/g;

    # <key2>
    # транслитерация учитывает включение символов \x{00b0}, * и элементов shortlong, TWOWORDS, hom
    # s/<key2>(.*?)<\/key2>/"<key2>" . &stags($1) . "<\/key2>"/ge;
    if (/<key2>$word<\/key2>/) { # key1 eq key2
        s/<key2>.*?<\/key2>//;
    } else {
        s/<key2>(.*?)<\/key2>/"<key2>" . &stags($1) . "<\/key2>"/e;
    }
   
    # <s>
    # транслитерация учитывает включение символов \x{00b0}, * и элемента <shortlong\/>
    # s/<s>(.*?)<\/s>/&stags($1)/ge;
    # оставлем теги, поскольку включение дополнительных элементов
    # s/<s>(.*?)<\/s>/"<s>" . &stags($1) . "<\/s>"/ge;
    # заменяем != strike
    s/<s>(.*?)<\/s>/"<sn>" . &stags($1) . "<\/sn>"/ge;
 
    return $_;
}

#------------------------------------------------
# подстановка греческих символов
#------------------------------------------------

sub greek {
    my ($l, $i) = @_;

    $l =~ s/(\.\d)0$/$1/; # 98138.60 -> 98138.6
    
    # 32059.1  1  -> 32059
    # 68437.1  1
    # 85921.1  1
    # 85921.1  2
    # 93282.1  1
    # 93282.1  2
    # 93282.1  3
    # 254842.1 1
    # 254842.1 2
    # 258787.1 1
    $l =~ s/\.\d// unless (exists $greek{$l});
    
    return ${$greek{$l}}[$i - 1];
}

#------------------------------------------------
# подстановка символов деванагари
#------------------------------------------------

sub stags {
   $_ = shift; 
   
   my @holder; 
    
   # замена элементов символом _
   push(@holder, $1) while (s/(\x{00b0}|\*|<shortlong\/>|<TWOWORDS\/>|<hom>.*?<\/hom>)/_/);
   
   $_ = slp1_utf8($_);
   
   # восстанавливаем элементы      
   1 while (s/_/shift(@holder)/e);
   
   return $_;
}

#------------------------------------------------
# транслятор slp1 -> utf8
#------------------------------------------------

sub slp1_utf8 {
    $_ = shift;
    
    s/([$W])/&w($1)/ge;
    
    s/([$X])/&x($1)/ge;
    s/([$C])([$V])/&c($1) . &vh($2)/ge;
    
    s/([$V])/&v($1)/ge;
    s/([$C])/&c($1) . "\x{094d}"/ge;
    
    return $_;
}

sub v {
    $_ = shift;

    return "\x{0905}" if ($_ eq 'a');
    return "\x{0906}" if ($_ eq 'A');
    return "\x{0907}" if ($_ eq 'i');
    return "\x{0908}" if ($_ eq 'I');
    return "\x{0909}" if ($_ eq 'u');
    return "\x{090a}" if ($_ eq 'U');
    return "\x{090b}" if ($_ eq 'f');
    return "\x{0960}" if ($_ eq 'F');
    return "\x{090c}" if ($_ eq 'x');
    return "\x{0961}" if ($_ eq 'X');
    return "\x{090f}" if ($_ eq 'e');
    return "\x{0910}" if ($_ eq 'E');
    return "\x{0913}" if ($_ eq 'o');
    return "\x{0914}" if ($_ eq 'O');
}

sub vh {
    $_ = shift;

    return "" if ($_ eq 'a');
    return "\x{093e}" if ($_ eq 'A');
    return "\x{093f}" if ($_ eq 'i');
    return "\x{0940}" if ($_ eq 'I');
    return "\x{0941}" if ($_ eq 'u');
    return "\x{0942}" if ($_ eq 'U');
    return "\x{0943}" if ($_ eq 'f');
    return "\x{0944}" if ($_ eq 'F');
    return "\x{0962}" if ($_ eq 'x');
    return "\x{0963}" if ($_ eq 'X');
    return "\x{0947}" if ($_ eq 'e');
    return "\x{0948}" if ($_ eq 'E');
    return "\x{094b}" if ($_ eq 'o');
    return "\x{094c}" if ($_ eq 'O');
}

sub c {
    $_ = shift;

    return  "\x{0915}" if ($_ eq 'k');
    return  "\x{0916}" if ($_ eq 'K');
    return  "\x{0917}" if ($_ eq 'g');
    return  "\x{0918}" if ($_ eq 'G');
    return  "\x{0919}" if ($_ eq 'N');
    return  "\x{091a}" if ($_ eq 'c');
    return  "\x{091b}" if ($_ eq 'C');
    return  "\x{091c}" if ($_ eq 'j');
    return  "\x{091d}" if ($_ eq 'J');
    return  "\x{091e}" if ($_ eq 'Y');
    return  "\x{091f}" if ($_ eq 'w');
    return  "\x{0920}" if ($_ eq 'W');
    return  "\x{0921}" if ($_ eq 'q');
    return  "\x{0922}" if ($_ eq 'Q');
    return  "\x{0923}" if ($_ eq 'R');
    return  "\x{0924}" if ($_ eq 't');
    return  "\x{0925}" if ($_ eq 'T');
    return  "\x{0926}" if ($_ eq 'd');
    return  "\x{0927}" if ($_ eq 'D');
    return  "\x{0928}" if ($_ eq 'n');
    return  "\x{092a}" if ($_ eq 'p');
    return  "\x{092b}" if ($_ eq 'P');
    return  "\x{092c}" if ($_ eq 'b');
    return  "\x{092d}" if ($_ eq 'B');
    return  "\x{092e}" if ($_ eq 'm');
    return  "\x{092f}" if ($_ eq 'y');
    return  "\x{0930}" if ($_ eq 'r');
    return  "\x{0932}" if ($_ eq 'l');
    return  "\x{0933}" if ($_ eq 'L');
    return  "\x{0933}\x{094d}\x{0939}\x{094d}" if ($_ eq '|');
    return  "\x{0935}" if ($_ eq 'v');
    return  "\x{0936}" if ($_ eq 'S');
    return  "\x{0937}" if ($_ eq 'z');
    return  "\x{0938}" if ($_ eq 's');
    return  "\x{0939}" if ($_ eq 'h');
}

sub x {
    $_ = shift;
    
    return "\x{0902}" if ($_ eq 'M');
    return "\x{0903}" if ($_ eq 'H'); 
}

sub w {
    $_ = shift;
    
    #return "\x{093d}" if ($_ eq '\'');
    return "\x{0964}" if ($_ eq '.'); 
    #return "\x{0965}" if ($_ eq '..');
    
    return  "\x{0966}" if ($_ eq '0');
    return  "\x{0967}" if ($_ eq '1');
    return  "\x{0968}" if ($_ eq '2');
    return  "\x{0969}" if ($_ eq '3');
    return  "\x{096a}" if ($_ eq '4');
    return  "\x{096b}" if ($_ eq '5');
    return  "\x{096c}" if ($_ eq '6');
    return  "\x{096d}" if ($_ eq '7');
    return  "\x{096e}" if ($_ eq '8');
    return  "\x{096f}" if ($_ eq '9');
}
