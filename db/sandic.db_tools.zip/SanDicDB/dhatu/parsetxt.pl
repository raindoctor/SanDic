use utf8;
use strict;

my @map1 = (
   ["IRR", "\x{0961}"], 
   ["IR",  "\x{090c}"],
   ["RR",  "\x{0960}"],
   ["ai",  "\x{0910}"],
   ["au",  "\x{0914}"],
   ["R",   "\x{090b}"], 
   ["A",   "\x{0906}"],
   ["I",   "\x{0908}"],
   ["U",   "\x{090a}"],
   ["a",   "\x{0905}"],
   ["i",   "\x{0907}"],
   ["u",   "\x{0909}"],
   ["e",   "\x{090f}"],
   ["o",   "\x{0913}"],
   ["M",   "\x{0902}"],
   ["H",   "\x{0903}"]);
   
my @map2 = (
   ["RR",  "\x{0944}"],
   ["IR",  "\x{0944}"], 
   ["ai",  "\x{0948}"],
   ["au",  "\x{094C}"],
   ["R",   "\x{0943}"],
   ["A",   "\x{093e}"],
   ["I",   "\x{0940}"],
   ["U",   "\x{0942}"],
   ["i",   "\x{093f}"],
   ["u",   "\x{0941}"],
   ["e",   "\x{0947}"],
   ["o",   "\x{094b}"]);
   
my @map3 = (
   ["kh",  "\x{0916}"],
   ["gh",  "\x{0918}"],
   ["ch",  "\x{091b}"],
   ["jh",  "\x{091d}"],
   ["Th",  "\x{0920}"],
   ["Dh",  "\x{0922}"],
   ["th",  "\x{0925}"],
   ["dh",  "\x{0927}"],
   ["ph",  "\x{092b}"],
   ["bh",  "\x{092d}"],
   ["z",   "\x{0936}"],
   ["G",   "\x{0919}"],
   ["c",   "\x{091a}"],
   ["J",   "\x{091e}"],
   ["S",   "\x{0937}"],
   ["k",   "\x{0915}"],
   ["g",   "\x{0917}"],
   ["j",   "\x{091c}"],
   ["T",   "\x{091f}"],
   ["D",   "\x{0921}"],
   ["N",   "\x{0923}"],
   ["t",   "\x{0924}"],
   ["d",   "\x{0926}"],
   ["n",   "\x{0928}"],
   ["p",   "\x{092a}"],
   ["b",   "\x{092c}"],
   ["m",   "\x{092e}"],
   ["y",   "\x{092f}"],
   ["r",   "\x{0930}"],
   ["l",   "\x{0932}"],
   ["v",   "\x{0935}"],
   ["s",   "\x{0938}"],
   ["h",   "\x{0939}"],
   ["L",   "\x{0933}"]);
   
my @map4 = ( 
   ["0",  "\x{0966}"],
   ["1",  "\x{0967}"],
   ["2",  "\x{0968}"],
   ["3",  "\x{0969}"],
   ["4",  "\x{096a}"],
   ["5",  "\x{096b}"],
   ["6",  "\x{096c}"],
   ["7",  "\x{096d}"],
   ["8",  "\x{096e}"],
   ["9",  "\x{096f}"]);

   
open(IN,  "<:utf8", "dhatu-patha.txt") or die;
open(OUT, ">:utf8", "dhatu.ready.txt") or die;

my (%rec, $ref, $line);
my $pspace = 1;

while (my $text = <IN>) {
   chomp($text);

   ++$line;
   
   if ($text =~ /^\s*$/ || $text =~ /^\s*---/) {
      $pspace = 1;
   } else {
   
      if ($text =~ /^\[(\w+)\]\s*(.+)/ && $pspace) {   # тип 1
         #print "$line\t $1, $2\n";
         $ref = \@{$rec{$1}{$line}};
         $text = $2;
      } elsif ($text =~ /^(\w+),\s*(.+)/ && $pspace) { # тип 2
         #print "$line\t $1, $2\n";
         $ref = \@{$rec{$1}{$line}};
         $text = $2;
      } elsif ($text =~ /^(\w+)/ && $pspace) {         # тип 3
         #print "$line\t $1, $2\n";
         die "ERR1";
      } 

      $pspace = 0;
      
      next unless $ref;
      
      $text =~ s/\t/ /g;
      $text =~ s/^\s*//;
      $text =~ s/\s\s+/ /g;
      
      push(@{$ref}, $text);
   }
   
   #last if $line >= 250;
}

flush();

sub flush() {
   foreach my $word (sort keys %rec) {
      print OUT "KEY: " . hk_utf8($word) . "\n";
      
      my $hom = keys %{$rec{$word}} > 1 ? 1 : 0; # 0 || 1
      
      foreach my $line (sort keys %{$rec{$word}}) {
            my $c = 1;
      
            foreach (@{$rec{$word}{$line}}) {
            
               s/<san>(.+?)<\/san>/hk_utf8($1)/eg;
               s/(\|)/\x{0964}/g; # danda
            
               if ($c == 1) {       # первая строка
        
                  if (/(.*)DR:(.*)/) {
                     $_ = hk_utf8($1) . "DR:" . hk_utf8($2);
                  } elsif (/(.*)\(BDK\)(.*)/) {
                     $_ = hk_utf8($1) . "(BDK)" . hk_utf8($2);
                  } else {
                     s/(.+)/hk_utf8($1)/e;
                  }
                  
               } elsif ($c == 2) { # вторая строка
               
                  if (/\((.+)\)/ && $1 =~ /\((.+)\)/) {     # (HK (text), HK)
                     s/\((.+)\(/"(" . hk_utf8($1) . "("/e;  # (HK (
                     s/\)(.+)\)/")" . hk_utf8($1) . ")"/e;  # ) HK)
                    
                  } else {
                     s/\((.+)\)/"(" . hk_utf8($1) . ")"/e;  # (HK)
                  }
                  
               } else {
                  s/(\w+){/hk_utf8($1) . "{"/ge;
                  s/}(\w+)/"}". hk_utf8($1)/ge;
                  s/{(\w+)}/"{" . hk_utf8($1) . "}"/ge;
                  s/\[(\w+)\]/"[" . hk_utf8($1) . "]"/ge;
               }
               
               s/([A-Za-z]{2,})/en_dia($1)/ge;
               s/(A)\./ā\./g;
               s/(G)/ṅ/g;
               s/option (I)/option ī/g;

               print OUT "HOM: $hom\n$_\n";
               
               $c++;
            }
            
         $hom++;
      }
      
      print OUT "\n";
   }
}

#------------------------------------------------
# транслятор Harvard-Kyoto -> utf8
#------------------------------------------------

sub hk_utf8 {
   my $txt = shift;
    
   for (@map3) { # consonant + virama
      $txt =~ s/$_->[0]/$_->[1]\x{094d}/g;
   }
   
   for (@map2) { # consonant - virama + vowels sign short
      $txt =~ s/([\x{0915}-\x{0939}])\x{094d}$_->[0]/$1$_->[1]/g;
   }
   
   $txt =~ s/([\x{0915}-\x{0939}])\x{094d}a/$1/g; # consonant + virama + a => consonant

   for (@map1, @map4) { 
      $txt =~ s/$_->[0]/$_->[1]/g;
   }
    
   return $txt;
}

#------------------------------------------------
# диакритика
#------------------------------------------------
sub en_dia {
   my $txt = shift;

   if ($txt !~ /blaze|buzz|criticize|ooze|sneeze|squeeze|squeezing|HOM|BDK|DR|RC|HNV|MPD/) {
      $txt =~ s/LR/ḷ/g;
      $txt =~ s/RR/ṝ/g;
      $txt =~ tr/AIUGJTDNzZSMHR/āīūṅñṭḍṇśŚṣṁḥṛ/;
   }
   
   return $txt;
}

