﻿use strict;

use DBI;

my $dbh = DBI->connect("dbi:SQLite:dbname=../sandic.db", undef, undef, 
                       {'RaiseError'     => 1,
                        'sqlite_unicode' => 1}) or die $DBI::errstr; 

$dbh->do("PRAGMA synchronous = OFF");
$dbh->do("PRAGMA temp_store  = MEMORY");

my @sth = ($dbh->prepare("INSERT INTO dictOrigins (name, author, desc, uri, lang) VALUES (?, ?, ?, ?, ?)"),
           $dbh->prepare("INSERT INTO dictAbbs (abb, desc, origin) VALUES (?, ?, ?)"), 
           $dbh->prepare("INSERT INTO dictEntries (word, hom, desc, origin) VALUES (?, ?, ?, ?)"));

open(IN, "<:utf8", "origin.txt") or die;
my @origin = split('#', <IN>);

$sth[0]->execute(@origin);

open(IN, "<:utf8", "abbreviations.txt") or die;

while (<IN>) {
   chomp;
   next if /^\s*$/;

   $sth[1]->execute(split(' = '), $origin[0]);
}           

open(IN, "<:utf8", "yukta.ready.txt") or die;
           
my (%ents, $word, $hom);

while (<IN>) {
   chomp;
   next if /^\s*$/;
    
   if (/^KEY:\s+(.+)/) {
      $word = $1;
   } elsif (/^HOM:\s+(.+)/) {
      $hom = $1;
   } else {
      if ($ents{$word}[$hom]) {
         $ents{$word}[$hom] .= "\n\n$_";
      } else {
         $ents{$word}[$hom] = $_;
      }
   }
}

foreach my $word (keys %ents) {
   # print "word: $word\n";

   $hom = 0;
   
   foreach (@{$ents{$word}}) {
      next unless $_; # если hom начинался не с 0
      $sth[2]->execute($word, $hom, $_, $origin[0]);
      $hom++;
   }
}

