use strict;

use LWP::UserAgent;
use HTML::LinkExtor;

my $num1 = 0; # 0 - 6
my $num2 = 0;

# page 001 == 7
my $url = "/cgi-bin/philologic/getobject.pl?p.$num1:$num2.apte";

my $ua   = LWP::UserAgent->new();
my $h    = HTTP::Headers->new(Content_Type => 'text/html, text/plain');
my $lext = HTML::LinkExtor->new(\&cb);

while (1) {
   my $req = HTTP::Request->new('GET', "http://dsal.uchicago.edu/$url", $h);

   my $res = $ua->request($req);

   $res->is_success or die "$url: " . $res->message;

   print "url: $url\n";

   my $file = "mirror/page_$num1" . "_$num2.html";
   
   open(FH, "> $file") or die "Can't open file";

   print FH $res->content;

   my $tmp = $num2;
   
   $lext->parse_file($file);
   
   last if $tmp == $num2;
}

sub cb {
   my($tag, %links) = @_;
     
   return if $tag eq 'img';

   foreach (keys %links) {
      next unless $links{$_} =~ /.apte$/;
   
      $links{$_} =~ /:(\d+).apte/;

      ($num2, $url) = ($1, $links{$_}) if ($1 > $num2);
   }  
 }