use utf8;
use strict;

use HTML::Parser;


my $p = HTML::Parser->new(api_version => 3,
                          start_h => [\&start_handler, "self, tagname, attr"],
                          end_h   => [\&end_handler, "self, tagname, attr"],
                          text_h  => [\&text_handler, "dtext"]);

mkdir("txt") or die;

my $id;

foreach my $subdir (0 .. 6) {    
   opendir(DIR, "mirror/$subdir") or die;
   
   while (defined (my $html = readdir(DIR))) {
      $id = undef;

      next if $html =~ /^\./;
      
      open(IN,  "<:utf8", "mirror/$subdir/$html")   or die;
      mkdir("txt/$subdir");
      open(OUT, ">:utf8", "txt/$subdir/$html.txt") or die;
      
      $p->parse_file(*IN);
   }
}

my ($div2, $span, $b);

sub start_handler {
   my ($self, $tagname, $attr) = @_;

   if ($tagname eq "div2") {
      $div2 = 1;
      $id = 1;
      print OUT "ID: $attr->{'id'}\n";
   }

   $span = 1  if $tagname eq "span";
   $b = 1     if $tagname eq "b";
   $div2 = 0  if $tagname eq "table" && $div2;
}

sub end_handler {
   my ($self, $tagname, $attr) = @_;
   
   if ($tagname eq "div2") {
      $div2 = 0;
      print OUT "\n\n"; 
   }
      
   $span = 0 if $tagname eq "span";
   $b = 0    if $tagname eq "b";
   
   # если начинается с продолжения, 
   # например page_0_1 продолжает page_0_0 
   $div2 = 1 if ($tagname eq "center");
}

sub text_handler {
   my $text = shift;
   
   chomp($text);

   $text =~ s/\n/ /g;
   
   if ($span) {
      # ID берем с span
      # page_1_0.html.txt
      # page_2_0.html.txt
      # page_3_0.html.txt
      # page_4_0.html.txt
      # page_5_0.html.txt
      # page_6_0.html.txt
      print OUT "\nID: $text\n" unless $id;
   } elsif ($b && $text =~ /(-?\d+)/) {
      print OUT "\nHOM: $text\n";
   } elsif ($div2) {
      print OUT "$text";
   }
}