use utf8;

use strict;

open(IN,  "<:utf8", "macdonell.txt") or die;
open(OUT, ">:utf8", "macdonell.ready.txt") or die;

my $manas = 'मनस';

while (<IN>) {
   chomp;
   
   1 while s/््/्/g;
   
   unless (/^\p{Devanagari}/) {
      s/^fg //; # 3428 fg ..  f. turning towards 
      s/^f//;   # 3429 f  ..  m. seeing, looking, sight;
      s/^\s\[/$manas \[/;    # 12208 ..  a. (î) relating to or pro duced from the mind, mental,
   }
   
   s/{093c}/\x{093c}/g;
   
   s/&atod;/a/g;
   s/&ntod;/n/g;
   
   s/&tdot;/t\x{0307}/g;
   s/&ndot;/n\x{0307}/g;
   
   s/&dot;/\x{00b7}/g;
   
   s/&(open|close);/'/g;
   
   s/\x{00b0}ree;/\x{02da}/g; 
   s/&root;/\x{221a}/g; 
   
   s/&abreve;/a\x{0306}/g; 
   s/&ibreve;/i\x{0306}/g;
   s/&ubreve;/u\x{0306}/g;
   
   s/&amacr;/a\x{0302}/g;
   s/&imacr;/i\x{0302}/g; 
   
   s/&asharp;/a\x{0302}\x{0301}/g; 
   s/&isharp;/i\x{0302}\x{0301}/g;
   s/&usharp;/u\x{0302}\x{0301}/g;
   
   s/&abrevcirc;/a\x{0306}\x{0302}/g; 
   s/&ibrevcirc;/i\x{0306}\x{0302}/g;
   s/&ubrevcirc;/u\x{0306}\x{0302}/g;
   
   s/&utilde;/u\x{0303}/g;
   
   s/&breve;/ \x{035c} /g;
   s/&half;/ \x{035c} /g;
   s/&halfacute;/\x{0301} \x{035c} /g;
   
   s/&ae;/\x{00e6}/g;
   s/&oe;/\x{0153}/g;

   s/&100;/\x{093d}/g;
   s/&zip;/~/g;
   
   1 while (s/(\s{2,})/ /);
   
   s/\[\s?(.+?)\s?\]/\[$1\]/g;
   
   print OUT "$_\n";
}