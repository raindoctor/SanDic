use utf8;

use HTML::Parser;

use strict;

my $p = HTML::Parser->new(api_version => 3);

$p->handler(start => \&start_handler, "tagname, self");
 
opendir(DIR, "mirror") or die;

while (defined (my $html = readdir(DIR))) {
   next if $html =~ /^\./;
   
   open(IN,  "<:utf8", "mirror/$html")   or die;
   open(OUT, ">:utf8", "txt/$html.txt") or die;
   
   $p->parse_file(*IN);
}

sub start_handler {
   my ($tagname, $self, $text) = @_;
   
   return if $tagname ne "p";
   
   $self->handler(text => sub { print OUT "$_[0]" }, "dtext");
}
