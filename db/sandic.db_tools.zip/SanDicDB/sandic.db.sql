/*
   sandic.db

   1. Маркирование и любые тэги не допускаются
   2. В пределах одной записи определения разделяются
      символами \n\n (одиночный символ \n зарезервирован для cr)
   3. hom == 0 и последовательно увеличивается на 1
*/
                        
CREATE VIRTUAL TABLE dictEntries USING fts4(word   TEXT NOT NULL, 
                                            hom    INTEGER DEFAULT 0, 
                                            desc   TEXT NOT NULL,
                                            origin TEXT NOT NULL); -- d_origins.name

CREATE TABLE dictAbbs (abb    TEXT NOT NULL,
                       desc   TEXT NOT NULL,
                       origin TEXT NOT NULL);
                       
CREATE TABLE dictOrigins (name   TEXT PRIMARY KEY, -- отображаемое имя
                          author TEXT NOT NULL,
                          desc   TEXT NOT NULL,
                          uri    TEXT,
                          lang   TEXT NOT NULL);                             

CREATE TABLE dictStats (recs   INTEGER NOT NULL, -- записей
                        words  INTEGER NOT NULL, -- уникальных слов
                        origin TEXT NOT NULL);   -- '-' для всех
                          
/*
Сокращения для авторитетных источников MW

CREATE TABLE authorities (name ???
                          abb    TEXT NOT NULL,
                          desc   TEXT NOT NULL,
                          origin TEXT NOT NULL);  
*/